//#include "Cell.h"
//#include "Unit.h"
//#include "LandUnit.h"
//#include <iostream>
//#include <map>
//
//LandUnit::LandUnit(int h, int d, Cell& c) : Unit(h, d, c)
//{
//	std::cout << "LandUnit(int h, damage d, Cell& c) : health (h), damage(d), cell(c)" << std::endl;
//}
//
//LandUnit::~LandUnit()
//{
//	std::cout << "LandUnit::~LandUnit()" << std::endl;
//}