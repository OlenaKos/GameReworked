//#include "Cell.h"
//#include "Unit.h"
//#include "CivilUnit.h"
//#include <iostream>
//#include <map>
//
//CivilUnit::CivilUnit(int h, int d, Cell& c) : Unit(h, d, c)
//{
//	std::cout << "CivilUnit(int h, damage d, Cell& c) : health (h), damage(d), cell(c)" << std::endl;
//}
//
//CivilUnit::~CivilUnit()
//{
//	std::cout << "CivilUnit::~CivilUnit()" << std::endl;
//}