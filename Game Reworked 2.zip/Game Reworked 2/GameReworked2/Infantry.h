//#pragma once
//#include "LandUnit.h"
//#include "MilitaryUnit.h"
//
//class Infantry : public LandUnit, public MilitaryUnit
//{
//private:
//
//	std::map <Cell::Landscape, int> AttackBonusMap;
//	std::map <Cell::Landscape, int> DefenceBonusMap;
//
//public:
//	Infantry(int h, int d, Cell& cell);
//	virtual ~Infantry();
//	virtual std::map <Cell::Landscape, int> getAttackBonusMap();
//	virtual std::map <Cell::Landscape, int> getDefenceBonusMap();
//};
//
