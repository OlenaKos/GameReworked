//#pragma once
//#include "Factory.h"
//#include "Unit.h"
//#include <string>
//
//class LandFactory : public Factory
//{
//	LandFactory();
//	~LandFactory();
//	Unit* getUnit(const std::string&);
//};
//
