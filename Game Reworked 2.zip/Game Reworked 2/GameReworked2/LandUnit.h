//#pragma once
//#include "Unit.h"
//#include "Cell.h"
//
//class LandUnit : public Unit
//{
//private:
//
//public:
//	LandUnit(int h, int ch, Cell& c);
//	virtual ~LandUnit();
//};