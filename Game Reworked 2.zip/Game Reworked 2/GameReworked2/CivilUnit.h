//#pragma once
//#include "Unit.h"
//#include "Cell.h"
//
//class CivilUnit : public Unit
//{
//private:
//
//public:
//	CivilUnit(int h, int ch, Cell& c);
//	virtual ~CivilUnit();
//};