//#include "Cell.h"
//#include "Unit.h"
//#include "MilitaryUnit.h"
//#include <iostream>
//#include <map>
//
//MilitaryUnit::MilitaryUnit(int h, int d, Cell& c) : Unit(h, d, c)
//{
//	std::cout << "MilitaryUnit(int h, damage d, Cell& c) : health (h), damage(d), cell(c)" << std::endl;
//}
//
//MilitaryUnit::~MilitaryUnit()
//{
//	std::cout << "MilitaryUnit::~MilitaryUnit()" << std::endl;
//}