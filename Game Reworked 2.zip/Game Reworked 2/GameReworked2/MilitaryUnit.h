//#pragma once
//#include "Unit.h"
//#include "Cell.h"
//
//class MilitaryUnit : public Unit
//{
//private:
//
//public:
//	MilitaryUnit(int h, int ch, Cell& c);
//	virtual ~MilitaryUnit();
//};